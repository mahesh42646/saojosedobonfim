"use client";
import React, { useState } from "react";
import Image from 'next/image';

const agents = [

    { name: "Staff 1", type: "", avatar: null },
];

function AgentDetails({ agent, onBack }) {
    const [tab, setTab] = React.useState("individual");
    return (
        <div>
            <div className="d-flex justify-content-between align-items-center">
                <h4 className="  fw-bold">
                    <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#222', fontWeight: 600, fontSize: 16, cursor: 'pointer', marginRight: 16 }}>←</button>
                    Staff Details</h4>
                <div className="d-flex me-2 gap-2">
                    <button className="rounded-5" style={{ background: '#eee', color: '#888', border: 'none', padding: '6px 36px', fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>Disable</button>
                    <button className="rounded-5" style={{ background: '#7CFC00', color: '#222', border: 'none', borderRadius: 16, padding: '6px 36px', fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>Active</button>
                </div>
            </div>
            <div style={{ maxWidth: '100%', margin: '0 auto', background: '#fff', borderRadius: 16, padding: 0, boxShadow: '0 2px 8px #0001', border: '2px solid #eee' }}>
                {/* Header */}
                <div style={{ background: '#f7f7f7', borderBottom: '1px solid #eee', padding: 24, borderTopLeftRadius: 16, borderTopRightRadius: 16 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                            {agent.avatar ? (
                                <Image 
                                    src={agent.avatar} 
                                    alt={agent.name} 
                                    width={56}
                                    height={56}
                                    style={{ borderRadius: '50%', objectFit: 'cover', background: '#eee' }}
                                />
                            ) : (
                                <div style={{ width: 56, height: 56, borderRadius: '50%', background: agent.color || '#ccc', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 24 }}>
                                    {agent.name.split(' ').length > 1 ? agent.name.split(' ').map(n => n[0]).join('') : agent.name[0]}
                                </div>
                            )}
                            <div>
                                <div style={{ fontWeight: 600, fontSize: 20 }}>{agent.name}</div>
                                <div style={{ color: '#222', fontSize: 15, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 8 }}>
                                    <span style={{ color: '#2ecc40', fontSize: 18 }}>●</span> Verified Agent
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                {/* Tabs */}
                <div style={{ display: 'flex', borderBottom: '1px solid #eee', paddingLeft: 24, gap: 32, marginTop: 0 }}>
                    <div onClick={() => setTab('individual')} style={{ cursor: 'pointer', padding: '18px 0 10px 0', borderBottom: tab === 'individual' ? '2px solid #2ecc40' : 'none', color: tab === 'individual' ? '#2ecc40' : '#222', fontWeight: tab === 'individual' ? 600 : 500, display: 'flex', alignItems: 'center', gap: 6 }}>
                    Detalhes {tab === 'individual'       }
                    </div>
                  
                </div>
                {/* Form */}
                <form style={{ padding: 32, display: 'flex', flexDirection: 'column', gap: 36 }}>
                    {/* Dados Pessoais */}
                    <div>
                        <div style={{ fontWeight: 700, fontSize: 22, marginBottom: 18 }}>Dados Pessoais</div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
                            
                            <div style={{ gridColumn: '1/3', display: 'flex', flexDirection: 'column', gap: 8 }}>
                                <label style={{ fontWeight: 500 }}>Tipo de funcionário *</label>
                                <select  style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #ccc', fontSize: 16 }} >
                                    <option>Selecione</option>
                                    <option>type 1</option>
                                    <option>type 2</option>
                                    <option>type 3</option>
                                </select>

                            </div>
                            <div style={{ gridColumn: '1/3', display: 'flex', flexDirection: 'column', gap: 8 }}>
                                <label style={{ fontWeight: 500 }}>CPF *</label>
                                <input placeholder="" style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #ccc', fontSize: 16 }} />
                            </div>
                            <div style={{ gridColumn: '1/3', display: 'flex', flexDirection: 'column', gap: 8 }}>
                                <label style={{ fontWeight: 500 }}>Nome completo *</label>
                                <input placeholder="" style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #ccc', fontSize: 16 }} />
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                <label style={{ fontWeight: 500 }}>E-mail *</label>
                                <input type="email"  style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #ccc', fontSize: 16 }}/>
                                    
                                
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                <label style={{ fontWeight: 500 }}>Sneha *</label>
                                <input type="password"  style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #ccc', fontSize: 16 }}/>
                                  
                                
                            </div>
                         
                        </div>
                    </div>
                  
                  
                </form>
            </div>
        </div>
    );
}

export default function AgentsPage() {
    const [selectedAgent, setSelectedAgent] = useState(null);
    const [isCreating, setIsCreating] = useState(false);

    return (
        <div className="ps-lg-5 pe-lg-2 px-2 py-lg-4 py-2" >
            {(selectedAgent || isCreating) ? (
                <div>
                    <AgentDetails
                        agent={selectedAgent || { name: "", type: "", avatar: null }}
                        onBack={() => { setSelectedAgent(null); setIsCreating(false); }}
                    />
                    {isCreating && (
                        <div style={{ display: 'flex', justifyContent: 'end', gap: 24, padding: 24 }}>
                            <button
                                style={{
                                    background: '#7CFC00',
                                    color: '#000',
                                    border: 'none',
                                    borderRadius: 24,
                                    padding: '6px 48px',
                                    fontWeight: 600,
                                    fontSize: 16,
                                    cursor: 'pointer'
                                }}
                            >
                                Criar funcionário
                            </button>
                        </div>
                    )}
                </div>
            ) : (
                <>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
                        <h2 style={{ margin: 0, fontWeight: 600, fontSize: 20 }}>Lista de funcionários</h2>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                            <input
                                type="text"
                                placeholder="Search agent"
                                style={{ border: '1px solid #ccc', borderRadius: 24, padding: '6px 24px', outline: 'none', width: 200 }}
                            />
                            <button
                                style={{ background: '#7CFC00', border: 'none', borderRadius: 24, padding: '8px 24px', fontWeight: 600, color: '#fff', cursor: 'pointer' }}
                                onClick={() => { setSelectedAgent(null); setIsCreating(true); }}
                            >
                                Novo funcionário
                            </button>
                        </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                        {agents.map((agent, idx) => (
                            <div
                                key={agent.name}
                                className="d-flex align-items-center gap-3 bg-transparent rounded-3 "
                                style={{ minHeight: 48, cursor: 'pointer', }}
                                onClick={() => { setSelectedAgent(agent); setIsCreating(false); }}
                            >
                                {agent.avatar ? (
                                    <Image
                                        src={agent.avatar}
                                        alt={agent.name}
                                        width={36}
                                        height={36}
                                        style={{ borderRadius: '50%', objectFit: 'cover' }}
                                    />
                                ) : (
                                    <div style={{ width: 36, height: 36, borderRadius: '50%', background: agent.color || '#ccc', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 18 }}>
                                        {agent.name.split(' ').length > 1 ? agent.name.split(' ').map(n => n[0]).join('') : agent.name[0]}
                                    </div>
                                )}
                                <div>
                                    <div style={{ fontWeight: 500, fontSize: 16 }}>{agent.name}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </>
            )}
        </div>
    );
}
