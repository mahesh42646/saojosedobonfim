"use client";
import React from 'react';

const SelectionProcess = () => {
  return (
    <div className="container-fluid">
      <h2>Selection Process</h2>
      <p>This section is under development.</p>
    </div>
  );
};

export default SelectionProcess;
