"use client";
import React, { useState } from "react";
import Image from 'next/image';
// import 'leaflet/dist/leaflet.css';

const spaces = [

  { name: "Projec 1", subtitle: "User 33", color: "#3B5998", type: "CENTRO", status: "approved" },
];

function SpaceDetails({ space, onBack }) {
  const [tab, setTab] = useState("update");
  return (
    <div className="ps-2">

      <h4 className=" mt-3  fw-bold">
        <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#222', fontWeight: 600, fontSize: 16, cursor: 'pointer', marginRight: 16 }}>←</button>
        Detalhes do Projeto Cultural</h4>

      <div style={{ maxWidth: 874, margin: '0 auto', background: '#fff', borderRadius: 16, border: '2px solid #eee', padding: 0 }}>
        <div style={{ backgroundColor: '#f7f7f7', padding: 14, borderBottom: '1px solid #eee', borderTopLeftRadius: 16, borderTopRightRadius: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: space.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ color: '#fff', fontSize: 32 }}><i className="bi bi-building"></i></span>
            </div>
            <div >
              <div style={{ fontWeight: 600, fontSize: 20 }}>{space.name || 'Cinema na Comunidade'}</div>
              <div style={{ color: '#222', fontSize: 15, fontWeight: 500 }}>TIPO: {space.type || 'CINEMA'}</div>
              <div style={{ fontSize: 15, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
                <span style={{ color: '#2F5711', fontSize: 18 }}><i className="bi bi-check-circle-fill"></i></span> Projeto aprovado e publicado
              </div>
            </div>
          </div>
        </div>
        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: '1px solid #eee', paddingLeft: 24, gap: 32, marginTop: 0 }}>
          <div onClick={() => setTab('update')} style={{ cursor: 'pointer', padding: '18px 0 10px 0', borderBottom: tab === 'update' ? '2px solid #2F5711' : 'none', color: tab === 'update' ? '#2F5711' : '#222', fontWeight: tab === 'update' ? 600 : 500, display: 'flex', alignItems: 'center', gap: 6 }}>
            Atualizações
          </div>
          <div onClick={() => setTab('details')} style={{ cursor: 'pointer', padding: '18px 0 10px 0', borderBottom: tab === 'details' ? '2px solid #2F5711' : 'none', color: tab === 'details' ? '#2F5711' : '#222', fontWeight: tab === 'details' ? 600 : 500, display: 'flex', alignItems: 'center', gap: 6 }}>
            Detalhes
          </div>
        </div>
        {/* Timeline/History */}
        {tab === 'update' && (
          <div style={{ padding: 32, paddingBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 24, marginBottom: 24 }}>
              <div style={{ minWidth: 32, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                <span style={{ color: '#2ecc40', fontSize: 22 }}>✔</span>
                <span style={{ color: '#2ecc40', fontSize: 22 }}>✔</span>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ marginBottom: 24 }}>
                  <div style={{ color: '#888', fontSize: 15 }}>segunda-feira, 5 de maio 21:51</div>
                  <div style={{ color: '#222', fontSize: 15 }}>Projeto criado com sucesso</div>
                </div>
                <div>
                  <div style={{ color: '#888', fontSize: 15 }}>sexta-feira, 9 de maio 10:01</div>
                  <div style={{ color: '#222', fontWeight: 600, fontSize: 15 }}>Projeto aprovado e publicado</div>
                </div>
              </div>
              <div style={{ minWidth: 400, display: 'flex', flexDirection: 'column', gap: 24 }}>
                <input value="Projeto aprovado e publicado" readOnly style={{ width: '100%', padding: 12, borderRadius: 24, border: '2px solid #eee', fontSize: 15 }} />
              </div>
            </div>
          </div>
        )}
        {tab === 'details' && (
          <form style={{ padding: 32, display: 'flex', flexDirection: 'column', gap: 24, background: '#fff' }}>
            {/* Project type */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <label style={{ fontWeight: 500 }}>Tipo de projeto *</label>
              <select style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #ccc', fontSize: 16 }}>
                <option>Selecione</option>
                <option>Tipo 1</option>
                <option>Tipo 2</option>
              </select>
            </div>
            {/* Project name */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <label style={{ fontWeight: 500 }}>Nome do projeto *</label>
              <input style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #ccc', fontSize: 16 }} />
            </div>
            {/* Description */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', background: '#F2F5F2', borderRadius: 8, padding: '8px 12px', gap: 8 }}>
                <span style={{ color: '#2F5711', fontSize: 20 }}><i className="bi bi-card-text"></i></span>
                <span style={{ fontWeight: 500 }}>Descrição *</span>
              </div>
              <textarea style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid #ccc', fontSize: 16, minHeight: 80, background: '#F7F7F7' }} 
              // defaultValue="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged." 
              />
            </div>
            {/* Project links */}
            <div style={{ background: '#F2F5F2', borderRadius: 12, padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ fontWeight: 600, marginBottom: 8 }}>Links do projeto</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ color: '#2F5711', fontSize: 22 }}><i className="bi bi-instagram"></i></span>
                <span style={{ fontWeight: 600 }}>Instagram</span>
                <label style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <input type="checkbox" defaultChecked style={{ accentColor: '#2F5711', width: 18, height: 18 }} />
                </label>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ color: '#2F5711', fontSize: 22 }}><i className="bi bi-youtube"></i></span>
                <span style={{ fontWeight: 600 }}>Youtube</span>
                <label style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <input type="checkbox" defaultChecked style={{ accentColor: '#2F5711', width: 18, height: 18 }} />
                </label>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ color: '#2F5711', fontSize: 22 }}><i className="bi bi-facebook"></i></span>
                <span style={{ fontWeight: 600 }}>Facebook</span>
                <label style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <input type="checkbox" defaultChecked style={{ accentColor: '#2F5711', width: 18, height: 18 }} />
                </label>
              </div>
              <input value="https://www.facebook.com/mapadaculturalnav/" readOnly style={{ width: '100%', padding: 10, borderRadius: 8, border: '1px solid #ccc', fontSize: 15, background: '#fff' }} />
            </div>
            {/* Project period */}
            <div style={{ background: '#F2F5F2', borderRadius: 12, padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ color: '#2F5711', fontSize: 22 }}><i className="bi bi-calendar"></i></span>
                <span style={{ fontWeight: 600 }}>Período de execução do projeto *</span>
              </div>
              <div style={{ display: 'flex', gap: 16, marginTop: 8 }}>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <label>Início *</label>
                  <input placeholder="__/__/_____" style={{ width: '100%', padding: 10, borderRadius: 8, border: '1px solid #ccc', fontSize: 15 }} />
                </div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <label>Final</label>
                  <input placeholder="__/__/_____" style={{ width: '100%', padding: 10, borderRadius: 8, border: '1px solid #ccc', fontSize: 15 }} />
                </div>
              </div>
            </div>
            {/* Photo gallery */}
            <div>
              <div style={{ fontWeight: 600, marginBottom: 8 }}>Galeria de fotos</div>
              <div style={{ display: 'flex', gap: 16 }}>
                <div style={{ width: 160, height: 170, background: '#FF0', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
                  <Image 
                    src="/images/card.png" 
                    alt="gallery" 
                    width={100}
                    height={100}
                    style={{ objectFit: 'cover' }}
                  />
                  <span style={{ position: 'absolute', top: 6, right: 8, color: '#2F5711', fontSize: 18, cursor: 'pointer' }}><i className="bi bi-x-circle-fill"></i></span>
                </div>
                <div style={{ width: 160, height: 170, background: '#FF0', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
                  <Image 
                    src="/images/card.png" 
                    alt="gallery" 
                    width={100}
                    height={100}
                    style={{ objectFit: 'cover' }}
                  />
                  <span style={{ position: 'absolute', top: 6, right: 8, color: '#2F5711', fontSize: 18, cursor: 'pointer' }}><i className="bi bi-x-circle-fill"></i></span>
                </div>
              </div>
            </div>
          </form>
        )}
        {/* Action Buttons */}

      </div>
      <div style={{ display: 'flex', justifyContent: 'end', gap: 24, padding: 24, borderTop: '1px solid #eee', borderBottomLeftRadius: 16, borderBottomRightRadius: 16 }}>
        <button style={{ background: '#F7f7f7', color: '#000', border: 'none', borderRadius: 24, padding: '6px 48px', fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>Inativo</button>
        <button style={{ background: '#B22222', color: '#fff', border: 'none', borderRadius: 24, padding: '6px 48px', fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>Reprovado</button>
        <button style={{ background: '#7CFC00', color: '#000', border: 'none', borderRadius: 24, padding: '6px 48px', fontWeight: 600, fontSize: 16, cursor: 'pointer' }}>Aprovado</button>
      </div>
    </div>
  );
}

export default function CspacePage() {
  const [selectedSpace, setSelectedSpace] = useState(null);
  return (
    <div className="ps-lg-5 pe-lg-2 px-2 py-lg-4 py-2" >
      {selectedSpace ? (
        <SpaceDetails space={selectedSpace} onBack={() => setSelectedSpace(null)} />
      ) : (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
            <h2 style={{ margin: 0, fontWeight: 600, fontSize: 22 }}>Lista de Projetos Culturais</h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <input
                type="text"
                placeholder="Procurar projeto cultural"
                style={{ border: '1px solid #ccc', borderRadius: 24, padding: '6px 24px', outline: 'none', width: 200 }}
              />
              <button style={{ background: '#7CFC00', border: 'none', borderRadius: 24, padding: '8px 24px', fontWeight: 600, color: '#fff', cursor: 'pointer' }}>
                Filtros
              </button>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {spaces.map((space, idx) => (
              <div
                key={space.name + idx}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 16,
                  background: 'transparent',
                  borderRadius: 20,
                  padding: '0px',
                  minHeight: 48,
                  cursor: 'pointer',
                }}
                onClick={() => setSelectedSpace(space)}
              >
                <div style={{ width: 36, height: 36, borderRadius: '50%', background: space.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <span style={{ color: '#fff', fontSize: 22 }}><i className="bi bi-building"></i></span>
                </div>
                <div>
                  <div style={{ fontWeight: 500, fontSize: 16 }}>{space.name}</div>
                  <div style={{ color: '#888', fontSize: 15 }}>{space.subtitle}</div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
