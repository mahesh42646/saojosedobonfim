"use client";
import React from 'react';

const Proposals = () => {
  return (
    <div className="container-fluid">
      <h2>Proposals</h2>
      <p>This section is under development.</p>
    </div>
  );
};

export default Proposals;
